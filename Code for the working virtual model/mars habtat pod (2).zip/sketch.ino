#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>

Adafruit_SSD1306 display(128, 64, &Wire, -1);
DHT dht(4, DHT22);

int soilPin = 34;
int gasPin = 35;
int pumpPin = 25;
int mistPin = 26;
int fanPin = 27;
int roverL = 16;
int roverR = 17;
int btn1 = 18;
int btn2 = 19;
int btnPage = 14;

int page = 1;
unsigned long stormTime = 0;
unsigned long dryTime = 0;
unsigned long pageDebounce = 0;
unsigned long pumpSec = 0;
unsigned long mistSec = 0;
unsigned long fanSec = 0;
unsigned long tick = 0;

void setup() {
  Serial.begin(115200);
  pinMode(pumpPin, OUTPUT);
  pinMode(mistPin, OUTPUT);
  pinMode(fanPin, OUTPUT);
  pinMode(roverL, OUTPUT);
  pinMode(roverR, OUTPUT);
  pinMode(btn1, INPUT_PULLUP);
  pinMode(btn2, INPUT_PULLUP);
  pinMode(btnPage, INPUT_PULLUP);

  dht.begin();
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(15, 25);
  display.println("MARS POD V2");
  display.display();
  delay(1000);
}

void loop() {
  if (digitalRead(btn1) == LOW) {
    stormTime = millis() + 8000;
  }
  if (digitalRead(btn2) == LOW) {
    dryTime = millis() + 8000;
  }
  if (digitalRead(btnPage) == LOW && millis() - pageDebounce > 300) {
    page = page + 1;
    if (page > 3) {
      page = 1;
    }
    pageDebounce = millis();
  }

  float t = dht.readTemperature();
  float h = dht.readHumidity();
  int soil = map(analogRead(soilPin), 0, 4095, 0, 100);
  int air = map(analogRead(gasPin), 0, 4095, 100, 0);

  if (millis() < stormTime) air = 20;
  if (millis() < dryTime) soil = 15;

  bool pumpOn = false;
  bool mistOn = false;
  bool fanOn = false;

  if (soil < 35) {
    digitalWrite(pumpPin, HIGH);
    pumpOn = true;
  } else {
    digitalWrite(pumpPin, LOW);
  }

  if (h < 45) {
    digitalWrite(mistPin, HIGH);
    mistOn = true;
  } else {
    digitalWrite(mistPin, LOW);
  }

  if (air < 50) {
    digitalWrite(fanPin, HIGH);
    fanOn = true;
  } else {
    digitalWrite(fanPin, LOW);
  }

  bool moving = true;
  if (millis() < stormTime) {
    moving = false;
    digitalWrite(roverL, LOW);
    digitalWrite(roverR, LOW);
  } else {
    digitalWrite(roverL, HIGH);
    digitalWrite(roverR, HIGH);
  }

  if (millis() - tick >= 1000) {
    if (pumpOn) pumpSec++;
    if (mistOn) mistSec++;
    if (fanOn) fanSec++;
    tick = millis();
  }

  display.clearDisplay();
  display.setCursor(0, 0);

  if (page == 1) {
    display.print("P1  TEMP:");
    display.print(t, 1);
    display.println("C");

    display.setCursor(0, 16);
    display.print("SOIL ");
    display.print(soil);
    display.print("%");
    display.drawRect(58, 16, 68, 8, WHITE);
    display.fillRect(58, 16, map(soil, 0, 100, 0, 68), 8, WHITE);

    display.setCursor(0, 30);
    display.print("HUM  ");
    display.print((int)h);
    display.print("%");
    display.drawRect(58, 30, 68, 8, WHITE);
    display.fillRect(58, 30, map((int)h, 0, 100, 0, 68), 8, WHITE);

    display.setCursor(0, 44);
    display.print("AIR  ");
    display.print(air);
    display.print("%");
    display.drawRect(58, 44, 68, 8, WHITE);
    display.fillRect(58, 44, map(air, 0, 100, 0, 68), 8, WHITE);

    display.setCursor(0, 56);
    if (millis() < stormTime) display.print("ALERT: CO2 STORM");
    else if (millis() < dryTime) display.print("ALERT: SOIL DRY");
    else display.print("STATUS: OK");
  }

  if (page == 2) {
    display.println("P2: SYSTEM TIMERS");
    display.setCursor(0, 16);
    display.print("Pump: ");
    display.print(pumpOn ? "ON " : "OFF");
    display.print(" ");
    display.print(pumpSec);
    display.println("s");

    display.setCursor(0, 30);
    display.print("Mist: ");
    display.print(mistOn ? "ON " : "OFF");
    display.print(" ");
    display.print(mistSec);
    display.println("s");

    display.setCursor(0, 44);
    display.print("Fan : ");
    display.print(fanOn ? "ON " : "OFF");
    display.print(" ");
    display.print(fanSec);
    display.println("s");

    display.setCursor(0, 56);
    display.print("Rover: ");
    display.println(moving ? "PATROL" : "STOP");
  }

  if (page == 3) {
    int score = (soil + (int)h + air) / 3;
    int sol = 1 + (millis() / 60000);
    display.println("P3: MISSION STATS");
    display.setCursor(0, 18);
    display.print("Sol Day : ");
    display.println(sol);
    display.setCursor(0, 32);
    display.print("Health  : ");
    display.print(score);
    display.println("%");
    display.setCursor(0, 46);
    display.print("O2 Gen  : ");
    display.println(fanOn ? "ACTIVE" : "IDLE");
  }

  display.display();
  delay(200);
}
