#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>

Adafruit_SSD1306 display(128, 64, &Wire, -1);
DHT dht(4, DHT22);

// pcb pins
int soilPin = 34;
int gasPin = 35;
int pumpPin = 25;
int mistPin = 26;
int fanPin = 27;
int btn1 = 18; // storm demo
int btn2 = 19; // drought demo

unsigned long stormTimer = 0;
unsigned long droughtTimer = 0;

void setup() {
  Serial.begin(115200);
  pinMode(pumpPin, OUTPUT);
  pinMode(mistPin, OUTPUT);
  pinMode(fanPin, OUTPUT);
  pinMode(btn1, INPUT_PULLUP);
  pinMode(btn2, INPUT_PULLUP);

  dht.begin();
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(10, 25);
  display.println("Mars Habitat Booting");
  display.display();
  delay(1000);
}

void loop() {
  if (digitalRead(btn1) == LOW) {
    stormTimer = millis() + 8000;
  }
  if (digitalRead(btn2) == LOW) {
    droughtTimer = millis() + 8000;
  }

  float t = dht.readTemperature();
  float h = dht.readHumidity();
  int soil = map(analogRead(soilPin), 0, 4095, 0, 100);
  int air = map(analogRead(gasPin), 0, 4095, 100, 0);

  if (millis() < stormTimer) {
    air = 20;
  }
  if (millis() < droughtTimer) {
    soil = 15;
  }

  bool pumpOn = false;
  bool mistOn = false;
  bool fanOn = false;

  if (soil < 35) {
    digitalWrite(pumpPin, HIGH);
    pumpOn = true;
  } else {
    digitalWrite(pumpPin, LOW);
  }

  if (h < 45) {
    digitalWrite(mistPin, HIGH);
    mistOn = true;
  } else {
    digitalWrite(mistPin, LOW);
  }

  if (air < 50) {
    digitalWrite(fanPin, HIGH);
    fanOn = true;
  } else {
    digitalWrite(fanPin, LOW);
  }

  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("MARS HABITAT POD");

  if (millis() < stormTimer) {
    display.println("ALERT: CO2 STORM");
  } else if (millis() < droughtTimer) {
    display.println("ALERT: SOIL DRY");
  } else {
    display.println("STATUS: OK");
  }

  display.print("Temp: ");
  display.print(t, 1);
  display.println(" C");

  display.print("Hum: ");
  display.print(h, 0);
  display.print("% Mist:");
  display.println(mistOn ? "ON" : "OFF");

  display.print("Soil: ");
  display.print(soil);
  display.print("% Pump:");
  display.println(pumpOn ? "ON" : "OFF");

  display.print("Air: ");
  display.print(air);
  display.print("% Fan:");
  display.println(fanOn ? "ON" : "OFF");

  display.display();
  delay(250);
}
